package cn.edu.nenu.repository;

import cn.edu.nenu.config.orm.PlatformRepository;
import cn.edu.nenu.domain.Storage;

/**
 * StorageRepository Class
 *
 */
public interface StorageRepository extends PlatformRepository<Storage,Integer> {
}
